import React, { useState } from 'react';

type Props = {
  config?: { targetScreen?: string; label?: string };
  style?: Record<string, any>;
};

export default function ScreenNavigationFlo({ config = {}, style = {} }: Props) {
  const targetScreen = config.targetScreen || 'Flo';
  const label = config.label || targetScreen;
  const [status, setStatus] = useState<'idle' | 'loading' | 'ok' | 'error'>('idle');

  async function goToScreen(e: React.MouseEvent<HTMLButtonElement>) {
    e.preventDefault();
    e.stopPropagation();
    setStatus('loading');
    try {
      const response = await fetch('/api/display/goto-screen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ screen: targetScreen }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setStatus('ok');
    } catch (err) {
      console.error('[Screen Navigation Flo]', err);
      setStatus('error');
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', boxSizing: 'border-box', display: 'flex',
      alignItems: 'center', justifyContent: 'center', padding: `${style.padding ?? 12}px`,
      borderRadius: `${style.borderRadius ?? 16}px`, background: style.backgroundColor ?? 'rgba(0,0,0,.35)',
      color: style.textColor ?? '#fff', overflow: 'hidden'
    }}>
      <button type="button" onClick={goToScreen} onPointerDown={(e) => e.stopPropagation()} style={{
        width: '100%', height: '100%', border: '1px solid rgba(255,255,255,.24)', borderRadius: '.8em',
        background: status === 'error' ? 'rgba(140,0,0,.65)' : 'rgba(255,255,255,.12)',
        color: 'inherit', font: 'inherit', fontSize: '1.35em', fontWeight: 600,
        cursor: 'pointer', touchAction: 'manipulation', userSelect: 'none'
      }}>
        {status === 'loading' ? '…' : label}
      </button>
    </div>
  );
}
