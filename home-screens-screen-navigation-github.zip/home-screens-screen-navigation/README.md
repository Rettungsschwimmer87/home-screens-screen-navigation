# Home Screens – Screen Navigation

Ein kleines Home-Screens-Plugin mit einem klick-/touchbaren Button, der direkt zu einem bestimmten Screen springt.

## Standardkonfiguration

- Ziel-Screen: `Flo`
- Button-Text: `Flo`
- Kategorie: `Media & Display`

Ziel-Screen und Button-Text können später in den Moduleinstellungen geändert werden.

## Installation aus GitHub Release

Home Screens erwartet bei **Install from URL** eine direkte HTTPS-URL auf ein `.tar.gz`-Archiv.

1. Dieses Repository bei GitHub hochladen, empfohlen als:
   `home-screens-screen-navigation`
2. Unter **Releases** ein neues Release mit Tag `v1.0.0` erstellen.
3. Die Datei aus `release/screen-navigation-flo-1.0.0.tar.gz` als Release Asset hochladen.
4. In Home Screens: **Plugins → Browse → Install from URL…**
5. Folgende URL einsetzen und `<DEIN-GITHUB-NAME>` ersetzen:

   `https://github.com/<DEIN-GITHUB-NAME>/home-screens-screen-navigation/releases/download/v1.0.0/screen-navigation-flo-1.0.0.tar.gz`

## Benutzung

Nach der Installation erscheint **Screen Navigation Flo** in der Kategorie **Media & Display**.

Das Modul auf einen Screen ziehen. Standardmäßig springt ein Klick auf den Screen `Flo`.

In den Moduleinstellungen lassen sich ändern:

- **Ziel-Screen** – Name oder ID des Ziel-Screens
- **Button-Text** – sichtbare Beschriftung

## Entwicklung

```bash
npm install
npm run build
```

Das erzeugt `dist/bundle.js`.

## Release-Tarball selbst neu erzeugen

Das Archiv muss einen einzelnen Top-Level-Ordner enthalten:

```text
screen-navigation-flo/
├── manifest.json
└── dist/
    └── bundle.js
```

Unter Linux/macOS zum Beispiel:

```bash
mkdir -p /tmp/screen-navigation-flo-pkg/screen-navigation-flo/dist
cp manifest.json /tmp/screen-navigation-flo-pkg/screen-navigation-flo/
cp dist/bundle.js /tmp/screen-navigation-flo-pkg/screen-navigation-flo/dist/
tar -czf screen-navigation-flo-1.0.0.tar.gz -C /tmp/screen-navigation-flo-pkg screen-navigation-flo
```
